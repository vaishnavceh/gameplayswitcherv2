﻿using INIFILE;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Game_Play : Form
    {
        public Game_Play()
        {
            InitializeComponent();
        }
                private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {


        }

        private void Activate_Click(object sender, EventArgs e)
        {


            MessageBox.Show("Activated Gameplay2.lua");
        }

        private void Deactivate_Click(object sender, EventArgs e)
        {

            string sourceFile = @".\modules\\gameplay2.lua";


            System.IO.File.Delete(sourceFile);

            MessageBox.Show("Deactivated Gameplay2.lua");

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
            {
                string sourceFile = @".\Data\Switcher~GM\gameplay2.lua";
                string destinationFile = @".\modules\\gameplay2.lua";

                System.IO.File.Copy(sourceFile, destinationFile);
                checkBox2.Text = "Activated";
            }
            else
            {
                string sourceFile = @".\modules\\gameplay2.lua";
                System.IO.File.Delete(sourceFile);

                checkBox2.Text = "Not Activated";
            }
            {
                Do_Checked();
            }
      }
        private void button6_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@".\Data\Switcher~GM\Setting\Click.wav");
            player.Play();
            INIFile inif = new INIFile(@".\gameplay.ini");
            inif.Write("gameplay", "ball_physics", textBox1.Text);
            inif.Write("gameplay", "ball_weight", textBox2.Text);
            inif.Write("gameplay", "ball_bounce", textBox3.Text);
            inif.Write("gameplay", "ball_friction", textBox4.Text);
            inif.Write("gameplay", "ball_magnus", textBox5.Text);
            inif.Write("gameplay", "ball_scale_x", textBox6.Text);
            inif.Write("gameplay", "ball_scale_y", textBox7.Text);
            inif.Write("gameplay", "ball_scale_z", textBox8.Text);
            inif.Write("gameplay", "shooting_power", textBox9.Text);
            inif.Write("gameplay","speed_global", textBox10.Text);

            label3.Text = ("Status:Work Done");
            MessageBox.Show("Values Added Succesfully");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            System.Media.SoundPlayer player = new System.Media.SoundPlayer(@".\Data\Switcher~GM\Setting\Click.wav");
            player.Play();
            this.Close();   
        }

        private void Game_Play_Load(object sender, EventArgs e)
        {
            Do_Checked();

        }

        private void Do_Checked()
        {
            textBox1.Enabled = checkBox2.Enabled;
        }
    



            
 }
        }



    

