﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Startup : Form
    {
        public Startup()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            var m = new Form1();
            m.Show();

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
